import React from 'react';

export default function (props) {
  console.log("props", props);

  return <h1>Hello world</h1>;
}
